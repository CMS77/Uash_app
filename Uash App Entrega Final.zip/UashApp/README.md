# Uash_app
Projeto de desenvolvimento móvel (grupo 9)

Documentação disponível em "Documentação", e os recursos necessários para os .mds em "resourses"



Esta branch do projeto está conectado por Version Control ao Android Studio
