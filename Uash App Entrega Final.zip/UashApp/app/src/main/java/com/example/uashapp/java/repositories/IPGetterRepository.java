package com.example.uashapp.java.repositories;

public interface IPGetterRepository {
    default String getLocalIP() {
        return "http://10.0.2.2:8080";
    }
}
