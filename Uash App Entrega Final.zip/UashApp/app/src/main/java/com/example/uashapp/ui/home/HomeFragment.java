package com.example.uashapp.ui.home;

import static android.content.Context.LOCATION_SERVICE;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;

import com.example.uashapp.AcceptLavagem;
import com.example.uashapp.MainActivity;
import com.example.uashapp.R;
import com.example.uashapp.java.app.AppData;
import com.example.uashapp.java.enums.StatusEnum;
import com.example.uashapp.java.enums.TipoLavagemEnum;
import com.example.uashapp.java.models.Lavagem;
import com.example.uashapp.java.models.Veiculo;
import com.example.uashapp.java.repositories.JsonReceiverRepository;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.MapView;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;


import com.example.uashapp.databinding.FragmentHomeBinding;

import org.json.JSONArray;
import org.json.JSONException;

import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.concurrent.ExecutionException;

public class HomeFragment extends Fragment implements OnMapReadyCallback, GoogleMap.OnMarkerClickListener {

    private FragmentHomeBinding binding;
    private ViewGroup context;
    private MapView mMap;
    private GoogleMap map;
    private LocationListener locationListener;
    protected LatLng lisboaCity = new LatLng(38.7436266, -9.1602032);
    protected MarkerOptions marker;
    protected Marker activeMarker;
    boolean allowMarkerUpdates;
    AppData app;

    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        HomeViewModel homeViewModel =
                new ViewModelProvider(this).get(HomeViewModel.class);

        binding = FragmentHomeBinding.inflate(inflater, container, false);
        View root = binding.getRoot();

        context = container;

        app = ((AppData)this.getActivity().getApplication());
        mMap = (MapView) root.findViewById(R.id.mapView2);
        mMap.onCreate(savedInstanceState);
        mMap.getMapAsync(this);

        LocationManager manager = (LocationManager) container.getContext()
                .getSystemService(LOCATION_SERVICE);
        if (ContextCompat.checkSelfPermission(container.getContext(), Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(getActivity(), new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, 1);

        } else if(ContextCompat.checkSelfPermission(container.getContext(), Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED)
        {
            ActivityCompat.requestPermissions(getActivity(), new String[]{Manifest.permission.ACCESS_COARSE_LOCATION}, 1);
        } else {
            locationListener = new LocationListener() {
                @Override
                public void onLocationChanged (Location location){
                    app.setCurrentLocation(location);
                    markerUpdate(location, activeMarker);
                }
            };
            manager.requestLocationUpdates(LocationManager.GPS_PROVIDER, 0, 0, locationListener);
            Location location = manager.getLastKnownLocation(LocationManager.GPS_PROVIDER);
        }

        /*JsonReceiverRepository task = new JsonReceiverRepository();
        try {
            HashMap<Integer, Lavagem> lavagemMap = new HashMap<Integer, Lavagem>();
            JSONArray Lavagens = task.execute("/api/lavagens").get();
            Lavagem currentLavagem;
            for (int i=0; i < Lavagens.length(); i++) {
                currentLavagem = new Lavagem(Lavagens, i);
                app = ((AppData)this.getActivity().getApplication());
                lavagemMap.put(currentLavagem.getServerID(), currentLavagem);
            }
            app.setLavagens(lavagemMap);
        } catch (ExecutionException e) {
            e.printStackTrace();
        } catch (InterruptedException e) {
            e.printStackTrace();
        } catch (JSONException e) {
            e.printStackTrace();
        }*/

        Button refreshButton = root.findViewById(R.id.refreshButton);
        refreshButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                JsonReceiverRepository task = new JsonReceiverRepository();
                try {
                    HashMap<Integer, Lavagem> lavagemMap = new HashMap<Integer, Lavagem>();
                    JSONArray Lavagens = task.execute("/api/lavagens").get();
                    Lavagem currentLavagem;
                    for (int i=0; i < Lavagens.length(); i++) {
                        currentLavagem = new Lavagem(Lavagens, i);
                        lavagemMap.put(currentLavagem.getServerID(), currentLavagem);
                    }
                    //app.setLavagens(lavagemMap);
                } catch (ExecutionException e) {
                    e.printStackTrace();
                } catch (InterruptedException e) {
                    e.printStackTrace();
                } catch (JSONException e) {
                    e.printStackTrace();
                } catch (NullPointerException e) {
                    e.printStackTrace();
                }
                app.setLavagens(Lavagem.populateLavagem());
                updateWashMarkers(map);
            }
        });

        final TextView textView = binding.textHome;
        homeViewModel.getText().observe(getViewLifecycleOwner(), textView::setText);
        return root;
    }

    public void onMapReady(GoogleMap googleMap) {
        map = googleMap;
        map.getUiSettings().setMyLocationButtonEnabled(false);

        map.moveCamera(CameraUpdateFactory.newLatLng(new LatLng(38.7, -9.1)));
        map.moveCamera(CameraUpdateFactory.newLatLng(lisboaCity));

        map.setMapType(GoogleMap.MAP_TYPE_SATELLITE);

        marker = new MarkerOptions()
                .position(lisboaCity).title("Posição Atual")
                .icon(BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_BLUE));
        activeMarker = map.addMarker(marker);
        activeMarker.setTag(0);

        map.moveCamera(CameraUpdateFactory.newLatLngZoom(lisboaCity, 11));

        if (ActivityCompat.checkSelfPermission(context.getContext(), Manifest.permission.ACCESS_FINE_LOCATION)
                != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(context.getContext(), Manifest.permission.ACCESS_COARSE_LOCATION)
                != PackageManager.PERMISSION_GRANTED) {
            return;
        }
        map.setMyLocationEnabled(true);
        allowMarkerUpdates = true;
        map.setOnMarkerClickListener(this);
    }

    @Override
    public boolean onMarkerClick(@NonNull Marker marker) {
        if ((Integer) marker.getTag() != 0) {
            Intent intent = new Intent(getContext(), AcceptLavagem.class);
            if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
                Lavagem wash = app.getLavagens().get(marker.getTag()); //new Lavagem(vehicle, TipoLavagemEnum.LAVAGEMASECO.getPrice(), TipoLavagemEnum.LAVAGEMASECO, "38.7436266,-9.1602032", LocalDateTime.now());
                intent.putExtra("washObject", wash);
            }
            getContext().startActivity(intent);
        }
        return false;
    }

    public void markerUpdate(Location location, Marker currentMarker) {
        if (allowMarkerUpdates && currentMarker != null) {
            Log.e("Marker", "updated!");
            currentMarker.setPosition(new LatLng(location.getLatitude(), location.getLongitude()));
        }
    }

    public void updateWashMarkers(GoogleMap map) {
        if (map != null) {
            Log.e("Debug", "Creating markers function start");
            HashMap<Integer, Lavagem> lavagemMap = app.getLavagens();
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                Log.e("Debug", "Creating markers");
                lavagemMap.forEach((key, value) -> {
                    Log.e("Debug", "Creating markers function middle");
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                        if(value.getStatus()==StatusEnum.SOLICITADO && value.getTime().isBefore(LocalDateTime.now().plusMinutes(30))) {
                            MarkerOptions newMarkerOptions = new MarkerOptions()
                                    .position(value.getPlace()).title(value.getVehicle().getType())
                                    .icon(BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_RED));
                            Marker newMarker = map.addMarker(newMarkerOptions);
                            newMarker.setTag(value.getServerID());
                            Log.e("Debug", "Creating markers function end");
                        } else {
                            Log.e("Debug", "false");
                        }
                    }
                });
            }
        }
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }

    @Override
    public void onResume() {
        super.onResume();
        mMap.onResume();
    }

    @Override
    public void onStart() {
        super.onStart();
        mMap.onStart();
    }

    @Override
    public void onStop() {
        super.onStop();
        mMap.onStop();
    }

    @Override
    public void onPause() {
        mMap.onPause();
        super.onPause();
    }

    @Override
    public void onDestroy() {
        mMap.onDestroy();
        super.onDestroy();
    }

    @Override
    public void onLowMemory() {
        super.onLowMemory();
        mMap.onLowMemory();
    }

}