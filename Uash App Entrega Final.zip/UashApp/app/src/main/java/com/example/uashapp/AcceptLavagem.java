package com.example.uashapp;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.example.uashapp.java.app.AppData;
import com.example.uashapp.java.enums.StatusEnum;
import com.example.uashapp.java.models.Lavagem;
import com.google.android.gms.maps.model.LatLng;

import java.text.DecimalFormat;

public class AcceptLavagem extends AppCompatActivity {

    AppData app;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_accept_lavagem);

        LocationManager manager = (LocationManager) getSystemService(LOCATION_SERVICE);
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, 1);

        } else if(ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED)
        {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.ACCESS_COARSE_LOCATION}, 1);
        } else {
            Location tempLocationHolder = manager.getLastKnownLocation(LocationManager.GPS_PROVIDER);
            LocationListener locationListener = new LocationListener() {
                @Override
                public void onLocationChanged(@NonNull Location location) {

                }
            };

            Intent intent = getIntent();
            Lavagem lavagem = (Lavagem) intent.getSerializableExtra("washObject");
            Button acceptButton = findViewById(R.id.acceptButton);
            acceptButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    app = ((AppData) getApplication());
                    //app.getLocalUser().getUasher().addReqService(lavagem);
                    lavagem.setStatus(StatusEnum.CONFIRMADO);
                    finish();
                }
            });
            if (tempLocationHolder == null) {
                manager.requestLocationUpdates(LocationManager.GPS_PROVIDER, 1000L, (float) 0, locationListener);
            } else {
                LatLng currentLocation = new LatLng(tempLocationHolder.getLatitude(), tempLocationHolder.getLongitude());

                TextView carType = findViewById(R.id.carType);
                TextView washType = findViewById(R.id.washType);
                TextView washDistance = findViewById(R.id.washDistance);
                TextView washPrice = findViewById(R.id.washPrice);

                carType.setText(lavagem.getVehicle().getType());
                washType.setText(lavagem.getWashType().getName());
                washDistance.setText(Lavagem.getDistance(currentLocation, lavagem.getPlace()));
                washPrice.setText(Integer.toString(lavagem.getValue()));

            }

        }

    }

    /*private String getDistance(LatLng startCoordinates, LatLng endCoordinates) {
        float[] results = new float[1];
        Location.distanceBetween(startCoordinates.latitude, startCoordinates.longitude,
                endCoordinates.latitude, endCoordinates.longitude,
                results);
        DecimalFormat format = new DecimalFormat("0.00");
        Log.e("Results", new LatLng(startCoordinates.latitude, startCoordinates.longitude).toString());
        Log.e("Results", new LatLng(endCoordinates.latitude, endCoordinates.longitude).toString());
        Log.e("Results", Double.parseDouble(format.format(results[0]/1000)) + " Km");
        return (Double.parseDouble(format.format(results[0]/1000)) + " Km");
    }*/
}