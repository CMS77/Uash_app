package com.example.uashapp.ui.profile;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ListView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;

import com.example.uashapp.R;
import com.example.uashapp.databinding.FragmentPerfilBinding;
import com.example.uashapp.java.app.AppData;
import com.example.uashapp.java.app.UserButtonsList;
import com.example.uashapp.java.app.UserButtonsListAdapter;
import com.example.uashapp.java.models.User;

public class ProfileFragment extends Fragment {

    private FragmentPerfilBinding binding;
    private ListView listView;
    private UserButtonsListAdapter listAdapter;
    private UserButtonsList availableButtons;
    AppData app;

    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        ProfileViewModel profileViewModel =
                new ViewModelProvider(this).get(ProfileViewModel.class);

        binding = FragmentPerfilBinding.inflate(inflater, container, false);
        View root = binding.getRoot();
        app = ((AppData)this.getActivity().getApplication());

        availableButtons = new UserButtonsList();
        listView = root.findViewById(R.id.washesButtonsListView);
        listAdapter = new UserButtonsListAdapter(
                container.getContext(),
                availableButtons.getTitles(), availableButtons.getImages());

        listView.setAdapter(listAdapter);
        TextView texto = (TextView) root.findViewById(R.id.washesIntroTextView);
        //User temp = new User("Nicole", "nicoledoceu@outlook.com", 910818503, "38.7436266, -9.1602032");
        //app.setLocalUser(temp);
        //app.getLocalUser().toJSONArray(app.getLocalUser(), false);
        texto.setText(app.getLocalUser().getName());

       // final TextView textView = binding.textHome;
       // homeViewModel.getText().observe(getViewLifecycleOwner(), textView::setText);
        return root;
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }
}