package com.example.uashapp.java.models;

import android.util.Log;

import com.example.uashapp.java.app.AppData;
import com.example.uashapp.java.enums.StatusEnum;
import com.example.uashapp.java.enums.TipoLavagemEnum;
import com.example.uashapp.java.repositories.JsonReceiverRepository;
import com.example.uashapp.java.repositories.JsonSenderRepository;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.Serializable;
import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.concurrent.ExecutionException;

public class Uasher implements Serializable {
    private static int currentLocalID = 1;
    private final int id;
    private int serverID;
    private int rating;
    private User user;
    private String license;
    private boolean hasEquipment;
    private String place;
    private Lavagem currentService;

    public JSONArray toJSONArray(Uasher uasher) {
        JSONObject tempUasher = new JSONObject();
        JSONArray result = new JSONArray();
        try {
            tempUasher.put("localizacao", this.place)
                    .put("rating", this.rating)
                    .put("cartaConducao", this.license)
                    .put("material", this.hasEquipment)
                    .put("user", this.user.toJSONObject(this.user, false))
                    .put("id", this.serverID);
            result.put(tempUasher);
            Log.e("Uasher", result.toString());
            return result;
        } catch (JSONException e) {
            e.printStackTrace();
            return null;
        }
    }

    public Uasher fromJSONArray(JSONArray array) throws JSONException {
        JSONObject uasherObject = array.getJSONObject(0);
        this.serverID = uasherObject.getInt("id");
        this.rating = uasherObject.getInt("rating");
        this.user = this.user.fromJSONArray(uasherObject.getJSONArray("user"));
        this.license = uasherObject.getString("cartaConducao");
        this.hasEquipment = uasherObject.getBoolean("material");
        this.place = uasherObject.getString("localizacao");
        return this;
    }

    public void sendUpdateUasher(String method) { // Chamar após atualizar os dados!
        JsonSenderRepository connection = new JsonSenderRepository();
        try {
            JSONArray serverUasher = connection.execute("/api/uashers/"+this.serverID, method, toJSONArray(this).toString()).get();
        } catch (ExecutionException e) {
            e.printStackTrace();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    public Uasher(JSONArray array) throws JSONException {
        this.id = currentLocalID;
        fromJSONArray(array);
        currentLocalID++;
    }

    public Uasher(User newUser, String newLicense) {
        this.user = newUser;
        this.license = newLicense;
        this.id = currentLocalID;
        JsonSenderRepository connection = new JsonSenderRepository();
        try {
            JSONArray serverUasher = connection.execute("/api/uashers/", "POST", toJSONArray(this).toString()).get();
            JSONObject serverUasherObject = serverUasher.getJSONObject(1); // Objeto do uasher deverá ser index 1, já que message é 0
            this.serverID = serverUasherObject.getInt("id");
        } catch (ExecutionException e) {
            e.printStackTrace();
        } catch (InterruptedException e) {
            e.printStackTrace();
        } catch (JSONException e) {
            e.printStackTrace();
        }
        currentLocalID++;
    }

    public int getID() {
        return this.id;
    }
    public int getServerID() {
        return this.serverID;
    }
    public int getServerInfo() {
        JsonReceiverRepository connection = new JsonReceiverRepository();
        try {
            JSONArray serverUasher = connection.execute("/api/uashers/"+this.serverID).get();
            JSONObject serverUasherObject = serverUasher.getJSONObject(0);
            this.setPlace(serverUasherObject.getString("localizacao"));
            this.setRating(serverUasherObject.getInt("rating"));
            this.setLicense(serverUasherObject.getString("cartaConducao"));
            this.setEquipment(serverUasherObject.getBoolean("material"));
        } catch (ExecutionException e) {
            e.printStackTrace();
        } catch (InterruptedException e) {
            e.printStackTrace();
        } catch (JSONException e) {
            e.printStackTrace();
        }
        return this.serverID;
    }
    public int getRating() { return this.rating; }
    public User getUser() {
        return this.user;
    }
    public String getLicense() {
        return this.license;
    }
    public boolean getEquipment() {
        return this.hasEquipment;
    }
    public String getPlace() {
        return this.place;
    }
    public Lavagem getCurrentServices() { return this.currentService; }

    public void setRating(int newRating) {
        this.rating = newRating;
    }
    public void setEquipment(Boolean newEquipment) {
        this.hasEquipment = newEquipment;
    }
    public void setLicense(String newLicense) {
        this.license = newLicense;
    }
    public void setPlace(String newPlace) {
        this.place = newPlace;
    }
    public void addReqService(Lavagem newService) {
        newService.setUasher(this);
        this.currentService = newService;
    }
    public void removeCurrentService(Lavagem pendingService) {
        pendingService.removeUasher();
        this.currentService = null;
    }
}
