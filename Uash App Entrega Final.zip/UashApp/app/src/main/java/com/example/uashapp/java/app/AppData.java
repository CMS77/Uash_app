package com.example.uashapp.java.app;

import android.app.Application;
import android.location.Location;
import android.util.Log;

import com.example.uashapp.java.enums.TipoLavagemEnum;
import com.example.uashapp.java.models.Lavagem;
import com.example.uashapp.java.models.Uasher;
import com.example.uashapp.java.models.User;
import com.example.uashapp.java.models.Veiculo;
import com.google.android.gms.maps.model.LatLng;

import java.time.LocalDateTime;
import java.util.HashMap;

public class AppData extends Application {
    private User localUser;
    private HashMap<Integer, Uasher> uasherRepositoryHolder = new HashMap<>();
    private HashMap<Integer, Lavagem> lavagemRepositoryHolder = new HashMap<>();
    private Location currentLocation;

    public void setLocalUser(User newUser) {
        this.localUser = newUser;
    }
    public void setUashers(HashMap<Integer, Uasher> uashers) {
        this.uasherRepositoryHolder.putAll(uashers);
    }
    public void setLavagens(HashMap<Integer, Lavagem> lavagens) {
        this.lavagemRepositoryHolder.putAll(lavagens);
    }
    public void setCurrentLocation(Location newLocation) {
        this.currentLocation = newLocation;
    }

    public User getLocalUser() {
        return this.localUser;
    }
    public HashMap<Integer, Uasher> getUashers() {
        return this.uasherRepositoryHolder;
    }
    public HashMap<Integer, Lavagem> getLavagens() {
        Log.e("Debug", this.lavagemRepositoryHolder.toString());
        return this.lavagemRepositoryHolder;
    }

    public Location getCurrentLocation() {
        return this.currentLocation;
    }
}
