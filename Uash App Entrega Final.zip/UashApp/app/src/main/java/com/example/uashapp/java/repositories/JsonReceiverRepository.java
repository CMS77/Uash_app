package com.example.uashapp.java.repositories;

import android.os.AsyncTask;
import android.util.Log;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

public class JsonReceiverRepository extends AsyncTask<String, Void, JSONArray> implements IPGetterRepository {

    /*
    Seguindo as aulas de Programação de Dispositivos Móveis, esse código é extremamente parecido. A funcionalidade de
    pesquisar por campos específicos foi removida e deverá ser feita no local onde esta função for chamada, caso necessário.
    Há um timeout de 20 segundos ao tentar efetuar a conexão, e um timeout de 10 segundos para a lida dos dados, antes do programa
    retornar uma excepção. O método default é "GET", o que nos dá a funcionalidade desejada; logo, não é necessário definir este.
     */

    @Override
    protected JSONArray doInBackground(String... params) {

        URL url;
        HttpURLConnection urlConnection = null;
        String result = "";

        try {
            url = new URL(getLocalIP() + params[0]); // Apenas aceita um URL por chamada, params[0] = url
            urlConnection = (HttpURLConnection) url.openConnection();
            urlConnection.setConnectTimeout(5000); //20000
            urlConnection.setReadTimeout(1000); //10000

            InputStream in = urlConnection.getInputStream();
            InputStreamReader reader = new InputStreamReader(in);

            int data = reader.read();
            while(data != -1) {
                int current = (int) data;
                result += current;
                data = reader.read();
            }

            Log.i("Debug", result);
            //JSONObject jsonObject = new JSONObject(result);
            //String resultInfo = jsonObject.getString(params[1]); // params[1] = campo de pesquisa
            JSONArray resultArray = new JSONArray(result);

            return resultArray;

        } catch(Exception e) {
            e.printStackTrace();
            return null;
        }

    }

    @Override
    protected void onPostExecute(JSONArray jsonArray) {
        try {
           if(jsonArray!=null) {
               Log.e("HTTP GET Result", jsonArray.toString(1));
           }
        } catch (JSONException e) {
            e.printStackTrace();
        }
        super.onPostExecute(jsonArray);
    }
}
