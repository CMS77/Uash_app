package com.example.uashapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.example.uashapp.java.app.AppData;
import com.example.uashapp.java.models.User;

public class RegistroActivity extends AppCompatActivity {

    AppData app;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registro);
        Button saveButton = (Button) findViewById(R.id.registro2);

        EditText nameBox = (EditText) findViewById(R.id.editTextTextPersonName);
        EditText emailBox = (EditText) findViewById(R.id.editTextTextEmailAddress);
        EditText passwordBox = (EditText) findViewById(R.id.editTextTextPassword);
        EditText phoneBox = (EditText) findViewById(R.id.editTextPhone);
        EditText dateBox = (EditText) findViewById(R.id.editTextDate);
        app = ((AppData)this.getApplication());

        saveButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(emailBox.getText()!=null) {
                    User temp = new User(nameBox.getText().toString(), emailBox.getText().toString(), Integer.parseInt(phoneBox.getText().toString()), "38.7436266, -9.1602032");
                    temp.setPassword(passwordBox.getText().toString());
                    temp.setBirthday(dateBox.getText().toString());
                    app.setLocalUser(temp);
                    temp.sendUpdateUser("PUT");
                    Toast.makeText(getApplicationContext(), "Registrado com sucesso!",Toast.LENGTH_SHORT).show();
                    Intent intent = new Intent(RegistroActivity.this, MainActivity.class);
                    startActivity(intent);
                }
            }
        });
    }
}