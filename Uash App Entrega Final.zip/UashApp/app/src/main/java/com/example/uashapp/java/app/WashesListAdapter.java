package com.example.uashapp.java.app;

import android.content.Context;
import android.content.Intent;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.uashapp.AcceptLavagem;
import com.example.uashapp.R;
import com.example.uashapp.java.enums.TipoLavagemEnum;
import com.example.uashapp.java.models.Lavagem;
import com.example.uashapp.java.models.Veiculo;
import com.google.android.gms.maps.model.LatLng;

import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

public class WashesListAdapter extends BaseAdapter {

    Context context;
    private final HashMap<Integer, Lavagem> lavagemMap;
    private LatLng currentLocation;
    private Iterator iterator;


    public WashesListAdapter(Context context, HashMap<Integer, Lavagem> lavagemMap, LatLng currentLocation)
    {
        this.context = context;
        this.lavagemMap = lavagemMap;
        this.iterator = lavagemMap.entrySet().iterator();
        this.currentLocation = currentLocation;
    }

    @Override
    public boolean isEnabled(int position) {
        return false;
    }

    @Override
    public int getCount() {
        return lavagemMap.size();
    }

    @Override
    public Object getItem(int position) {
        return position;
    }

    @Override
    public long getItemId(int id) {
        return id;
    }



    @Override
    public View getView(int position, View convertView,
                        ViewGroup parent) {

        ViewHolder viewHolder;

        final View result;

        if (iterator.hasNext()) {
            Map.Entry entry = (Map.Entry) iterator.next();
            Lavagem currentLavagem = (Lavagem) entry.getValue();
            Log.e("Debug", currentLavagem.getPlaceString());

            if (convertView == null) {
                viewHolder = new ViewHolder();
                LayoutInflater inflater = LayoutInflater.from(context);
                convertView = inflater.inflate(R.layout.lavagens_button_items, parent, false);
                viewHolder.washPrice = (TextView) convertView.findViewById(R.id.washPrice2);
                viewHolder.washCarType = (TextView) convertView.findViewById(R.id.washCarType);
                viewHolder.washButtonType = (TextView) convertView.findViewById(R.id.washButtonType);
                viewHolder.washLocation = (TextView) convertView.findViewById(R.id.washLocation);

                result=convertView;

                convertView.setTag(viewHolder);

                viewHolder.washCarType.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        Log.i("LISTVIEW", "TextView click"+position);
                        Intent intent = new Intent(context, AcceptLavagem.class);
                        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
                            intent.putExtra("washObject", currentLavagem);
                        }
                        context.startActivity(intent);
                    }
                });

            } else {
                viewHolder = (ViewHolder) convertView.getTag();
                result=convertView;
            }

            Log.e("Debug", currentLavagem.getPlaceString());
            viewHolder.washPrice.setText(Integer.toString(currentLavagem.getValue()));
            viewHolder.washCarType.setText(currentLavagem.getVehicle().getType());
            viewHolder.washButtonType.setText(currentLavagem.getWashType().getName());
            viewHolder.washLocation.setText(Lavagem.getDistance(currentLocation, currentLavagem.getPlace()));
        }

        return convertView;
    }

    private static class ViewHolder {

        TextView washPrice;
        TextView washCarType;
        TextView washLocation;
        TextView washButtonType;

    }
}


