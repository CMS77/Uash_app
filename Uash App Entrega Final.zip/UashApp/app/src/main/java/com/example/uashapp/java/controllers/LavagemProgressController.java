package com.example.uashapp.java.controllers;

//TODO: Será necessário para garantir que ambos usuário e uasher concordam com o prosseguimento/conclusão da lavagem

public class LavagemProgressController {

}
