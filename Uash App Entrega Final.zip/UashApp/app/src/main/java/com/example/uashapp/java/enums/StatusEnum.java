package com.example.uashapp.java.enums;

public enum StatusEnum {
    SOLICITADO("Solicitado"),
    CONFIRMADO("Confirmado"),
    AGENDADO("Agendado"),
    CANCELADO("Cancelado"),
    CONCLUIDO("Concluído");
    private String status;
    public String getStatus() { return this.status; }
    private StatusEnum(String newStatus) { this.status = newStatus; }
}
