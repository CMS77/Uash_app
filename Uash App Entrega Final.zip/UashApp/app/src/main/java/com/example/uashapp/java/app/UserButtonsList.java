package com.example.uashapp.java.app;

import com.example.uashapp.R;

public class UserButtonsList {

    int[] images = {
            R.drawable.ic_new,
            R.drawable.ic_new,
            R.drawable.ic_new,
            R.drawable.ic_new
    };

    String[] titles = {
            "Perfil Uasher",
            "Página de Veículos",
            "Avaliações",
            "Configurar Usuário",
    };

    public int[] getImages() {return this.images;}
    public String[] getTitles() {return this.titles;}
    public UserButtonsList() {}
}
