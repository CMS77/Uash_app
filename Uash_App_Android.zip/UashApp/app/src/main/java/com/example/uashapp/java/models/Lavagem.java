package com.example.uashapp.java.models;

import android.util.Log;

import androidx.annotation.NonNull;

import com.example.uashapp.java.enums.RatingEnum;
import com.example.uashapp.java.enums.StatusEnum;
import com.example.uashapp.java.enums.TipoLavagemEnum;
import com.example.uashapp.java.repositories.JsonSenderRepository;
import com.google.android.gms.maps.model.LatLng;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.Serializable;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.HashMap;
import java.util.concurrent.ExecutionException;

public class Lavagem implements Serializable {
    private static int currentLocalID = 1;
    private final int id;
    private int serverID;
    private Veiculo vehicle;
    private Uasher uasher;
    private int value;
    private int rating;
    private TipoLavagemEnum washType;
    private String place;
    private LocalDateTime time;
    private StatusEnum status;

    public JSONArray toJSONArray(Lavagem lavagem) {
        JSONObject tempWash = new JSONObject();
        JSONArray result = new JSONArray();
        try {
            tempWash.put("status", this.status.getStatus())
                    .put("valor", this.washType.getPrice())
                    .put("tipoLavagem", this.washType.getName())
                    .put("rating", this.time)
                    .put("localizacao", this.place)
                    .put("horario", this.time)
                    .put("uasher", this.uasher.toJSONArray(this.uasher))
                    .put("veiculo", this.vehicle.toJSONArray(this.vehicle))
                    .put("id", this.serverID);
                   // .put("user", this.user.toJSONArray(user));
            Log.e("Lavagem", result.toString());
            result.put(tempWash);
            return result;
        } catch (JSONException e) {
            e.printStackTrace();
            return null;
        }
    }

    private void fromJSONArray(JSONArray array, Integer index) throws JSONException {
        JSONObject lavagemObject = array.getJSONObject((index!=null) ? index : 0);
        this.serverID = lavagemObject.getInt("id");
        this.vehicle = this.vehicle.fromJSONArray(lavagemObject.getJSONArray("veiculo"));
        this.uasher = this.uasher.fromJSONArray(lavagemObject.getJSONArray("uasher"));
        this.value = lavagemObject.getInt("valor");
        this.washType = TipoLavagemEnum.valueOf(lavagemObject.getString("tipoLavagem"));
        this.status = StatusEnum.valueOf(lavagemObject.getString("status"));
        this.place = lavagemObject.getString("localizacao");
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
            DateTimeFormatter formatter = DateTimeFormatter.ofPattern("YYYY-MM-DDTHH:MM:SS");
            this.time = LocalDateTime.parse(lavagemObject.getString("horario"), formatter);
        }
        this.status = StatusEnum.SOLICITADO;
    }

    private void sendUpdateLavagem(String method) { // Chamar após atualizar os dados!
        JsonSenderRepository connection = new JsonSenderRepository();
        try {
            JSONArray serverUser = connection.execute("/api/users/"+this.serverID, method, toJSONArray(this).toString()).get();
        } catch (ExecutionException e) {
            e.printStackTrace();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    public Lavagem(JSONArray array, Integer index) throws JSONException {
        this.id = currentLocalID;
        fromJSONArray(array, index);
        currentLocalID++;
    }
    public Lavagem(@NonNull Veiculo newVehicle, int newValue, TipoLavagemEnum newWashType, String newPlace, LocalDateTime newTime) {
        this.id = currentLocalID;
        this.vehicle = newVehicle;
        this.value = newValue;
        this.washType = newWashType;
        this.place = newPlace;
        this.time = newTime;
        this.status = StatusEnum.SOLICITADO;
        currentLocalID++;
    }

    public int getID() {
        return this.id;
    }
    public int getServerID() {
        return this.serverID;
    }
    public Veiculo getVehicle() { return this.vehicle; }
    //public Veiculo getVehicle() { return this.client.getVehicles(); }
    public Uasher getUasher() { return this.uasher; }
    public int getValue() {
        return this.value;
    }
    public int getRating() {
        return this.rating;
    }
    public TipoLavagemEnum getWashType() {
        return this.washType;
    }
    public LatLng getPlace() {
        String[] coordsHolder = this.place.split(",");
        double lat = Double.parseDouble(coordsHolder[0]);
        double lng = Double.parseDouble(coordsHolder[1]);
        LatLng result = new LatLng(lat, lng);
        return result;
    }
    public String getPlaceString() {
        return this.place;
    }
    public LocalDateTime getTime() {
        return this.time;
    }
    public StatusEnum getStatus() {
        return this.status;
    }

    public static HashMap<Integer, Lavagem> populateLavagem() {
        Log.e("Debug", "Started populating");
        HashMap<Integer, Lavagem> lavagemMap = new HashMap<Integer, Lavagem>();
        Veiculo vehicle1 = new Veiculo("Toyota Yares", "ALFJ22");
        Lavagem wash1 = null;
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
            wash1 = new Lavagem(vehicle1, TipoLavagemEnum.LAVAGEMASECO.getPrice(), TipoLavagemEnum.LAVAGEMASECO, "38.7436266,-9.1602032", LocalDateTime.now());
            wash1.setServerID(1);
        }
        lavagemMap.put(wash1.getServerID(), wash1);
        Log.e("Debug", lavagemMap.toString());
        Log.e("Debug", "Finished populating");
        return lavagemMap;
    }

    public void setServerID(int newServerID) {
        Log.e("Debug", "Assigning Server ID for debugging");
        this.serverID = newServerID;
    }
    public void setValue(int newValue) {
        this.value = newValue;
    }
    public void setRating(int newRating) {
        this.rating = newRating;
    }
    public void setPlace(String newPlace) {
        this.place = newPlace;
    }
    public void setTime(LocalDateTime newTime) {
        this.time = newTime;
    }
    public void setStatus(StatusEnum newStatus) {
        this.status = newStatus;
    }
    public void setUasher(Uasher newUasher) { this.uasher = newUasher; }
    public void removeUasher() { this.uasher = null; } // talvez não seja necessário se setUasher aceitar null

    public void deleteService() {
        this.uasher.removeCurrentService(this);
        this.uasher = null;
    }
}
