package com.example.uashapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.example.uashapp.java.app.AppData;

public class LoginActivity extends AppCompatActivity {
    AppData app;
    Button loginBotao,registro;
    EditText email,password;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        app = ((AppData)this.getApplication());

        email = (EditText) findViewById(R.id.emailbox);
        password = (EditText) findViewById(R.id.passbox);
        loginBotao = (Button) findViewById(R.id.buttonlogin);
        registro = (Button) findViewById(R.id.reg);

        registro.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(LoginActivity.this, RegistroActivity.class);
                startActivity(intent);
            }
        });

        loginBotao.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                login(v);
            }
        });
    }


    public void login(View view) {
        //correct password
        if(email.getText().toString().equals("admin") && password.getText().toString().equals("admin")) {

        } else {
            //wrong password
            Toast.makeText(getApplicationContext(), "Senha inválida",Toast.LENGTH_SHORT).show();
        }
    }
}
