package com.example.uashapp.java.enums;

public enum RatingEnum {
    EXCELENTE(5),
    BOM(4),
    MEDIO(3),
    RUIM(2),
    MUITORUIM(1);

    private int rating;
    private RatingEnum(int rating) {
        this.rating = rating;
    }
    void RatingOpcao(int ratingOp){
        rating = ratingOp;
    }
    public int ratingOp(){
        return rating;
    }

}