package com.example.uashapp.java.app;

import android.content.Context;
import android.content.Intent;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.uashapp.AcceptLavagem;
import com.example.uashapp.R;
import com.example.uashapp.java.enums.TipoLavagemEnum;
import com.example.uashapp.java.models.Lavagem;
import com.example.uashapp.java.models.Veiculo;

import java.time.LocalDateTime;

public class UserButtonsListAdapter extends BaseAdapter {

    Context context;
    private final String [] values;
    private final int [] images;


    public UserButtonsListAdapter(Context context, String[] values, int[] images)
    {
        this.context = context;
        this.values = values;
        this.images = images;
    }

    @Override
    public boolean isEnabled(int position) {
        return false;
    }

    @Override
    public int getCount() {
        return values.length;
    }

    @Override
    public Object getItem(int position) {
        return position;
    }

    @Override
    public long getItemId(int id) {
        return id;
    }



    @Override
    public View getView(int position, View convertView,
                        ViewGroup parent) {

        ViewHolder viewHolder;

        final View result;

        if (convertView == null) {

            viewHolder = new ViewHolder();
            LayoutInflater inflater = LayoutInflater.from(context);
            convertView = inflater.inflate(R.layout.user_button_items, parent, false);
            viewHolder.txtName = (TextView) convertView.findViewById(R.id.washCarType);
            viewHolder.icon = (ImageView) convertView.findViewById(R.id.itemIcon);

            result=convertView;

            convertView.setTag(viewHolder);

            // Click nos item da listview
            viewHolder.icon.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    Log.i("LISTVIEW", "Image click"+position);
                }
            });

            viewHolder.txtName.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    Log.i("LISTVIEW", "TextView click"+position);
                    Intent intent = new Intent(context, AcceptLavagem.class);
                    Veiculo vehicle = new Veiculo("Toyota Yares", "ALFJ22");
                    if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
                        Lavagem wash = new Lavagem(vehicle, TipoLavagemEnum.LAVAGEMASECO.getPrice(), TipoLavagemEnum.LAVAGEMASECO, "38.7436266,-9.1602032", LocalDateTime.now());
                        intent.putExtra("washObject", wash);
                    }
                    context.startActivity(intent);
                }
            });

        } else {
            viewHolder = (ViewHolder) convertView.getTag();
            result=convertView;
        }

        viewHolder.txtName.setText(values[position]);
        viewHolder.icon.setImageResource(images[position]);

        return convertView;
    }

    private static class ViewHolder {

        TextView txtName;
        ImageView icon;

    }
}


