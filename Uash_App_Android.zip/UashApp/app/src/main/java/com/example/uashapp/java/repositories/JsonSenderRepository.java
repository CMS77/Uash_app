package com.example.uashapp.java.repositories;

import android.os.AsyncTask;
import android.util.Log;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.URL;

public class JsonSenderRepository extends AsyncTask<String, Void, JSONArray> implements IPGetterRepository {

    /*
    Este código foi baseado nas aulas de Programação de Dispositivos Móveis. Esse código é capaz de fazer
    o envio de dados (terceiro argumento) ao URL destino (primeiro argumento) por qualquer método HTTP (segundo argumento).
    Há um timeout de 20 segundos ao tentar efetuar a conexão antes do programa retornar uma excepção.
     */

    @Override
    protected JSONArray doInBackground(String... params) {

        URL url;
        HttpURLConnection urlConnection = null;
        String result = "";

        try {
            url = new URL(getLocalIP() + params[0]); // Apenas aceita um URL por chamada, field[0] = url
            urlConnection = (HttpURLConnection) url.openConnection();
            urlConnection.setConnectTimeout(5000); //20000
            urlConnection.setReadTimeout(1000); //10000
            urlConnection.setRequestMethod(params[1]); // POST ou PUT ou DELETE

            OutputStream out = urlConnection.getOutputStream();
            InputStream in = urlConnection.getInputStream();
            OutputStreamWriter writer = new OutputStreamWriter(out);
            InputStreamReader reader = new InputStreamReader(in);

            writer.write(params[2]); // params[2] = campo de entrada
            writer.flush();
            writer.close();
            out.close();

            int data = reader.read();
            while(data != -1) {
                int current = (int) data;
                result += current;
                data = reader.read();
            }

            //~~Será necessário ler o ID e códigos de sucesso que o servidor retorna para objetos, por meio de um return~~ Feito! :D
            JSONArray resultArray = new JSONArray(result);

            return resultArray;

        } catch(Exception e) {
            e.printStackTrace();
            return null;
        }

    }

    @Override
    protected void onPostExecute(JSONArray jsonArray) {
        try {
            if(jsonArray!=null) {
                Log.e("HTTP SEND Result", jsonArray.toString(1));
            }
        } catch (JSONException e) {
            e.printStackTrace();
        }
        super.onPostExecute(jsonArray);
    }
}
