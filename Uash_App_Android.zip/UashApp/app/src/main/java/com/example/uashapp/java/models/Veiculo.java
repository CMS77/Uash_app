package com.example.uashapp.java.models;

import android.os.Build;
import android.util.Log;

import com.example.uashapp.java.repositories.JsonReceiverRepository;
import com.example.uashapp.java.repositories.JsonSenderRepository;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.Serializable;
import java.util.HashMap;
import java.util.concurrent.ExecutionException;

public class Veiculo implements Serializable {
    private static int currentLocalID = 1;
    private final int id;
    private int serverID;
    private String type;
    private String registry;
    private String place;
    private HashMap<Integer, User> owners;

    public JSONArray toJSONArray(Veiculo vehicle) {
        JSONObject tempVehicle = new JSONObject();
        JSONArray result = new JSONArray();
        try {
            tempVehicle.put("tipo", this.type)
                    .put("localizacao", this.place)
                    .put("matricula", this.registry)
                    .put("id", this.serverID);
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                JSONArray usersArray = new JSONArray();
                owners.forEach((k,v) -> {
                    usersArray.put(v.toJSONArray(v));
                });
                tempVehicle.put("user", usersArray);
            }
            result.put(tempVehicle);
            Log.e("Veículo", result.toString());
            return result;
        } catch (JSONException e) {
            e.printStackTrace();
            return null;
        }
    }

    public Veiculo fromJSONArray(JSONArray array) throws JSONException {
        JSONObject veiculoObject = array.getJSONObject(0);
        this.serverID = veiculoObject.getInt("id");
        this.type = veiculoObject.getString("tipo");
        this.registry = veiculoObject.getString("matricula");
        this.place = veiculoObject.getString("localizacao");
        return this;
    }

    public void sendUpdateVeiculo(String method) { // Chamar após atualizar os dados!
        JsonSenderRepository connection = new JsonSenderRepository();
        try {
            JSONArray serverVeiculo = connection.execute("/api/veiculos/"+this.serverID, method, toJSONArray(this).toString()).get();
        } catch (ExecutionException e) {
            e.printStackTrace();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    public Veiculo(String newType, String newRegistry) {
        this.type = newType;
        this.registry = newRegistry;
        this.id = currentLocalID;
        this.owners = new HashMap<Integer, User>();
        JsonSenderRepository connection = new JsonSenderRepository();
        try {
            JSONArray serverVeiculo = connection.execute("/api/veiculos/", "POST", toJSONArray(this).toString()).get();
            JSONObject serverVeiculoObject = serverVeiculo.getJSONObject(1); // Objeto do veiculo deverá ser index 1, já que message é 0
            this.serverID = serverVeiculoObject.getInt("id");
        } catch (ExecutionException e) {
            e.printStackTrace();
        } catch (InterruptedException e) {
            e.printStackTrace();
        } catch (JSONException e) {
            e.printStackTrace();
        } catch (NullPointerException e) {
        e.printStackTrace();
        }

        currentLocalID++;
    }

    public Veiculo(String newType, String newRegistry, String newPlace) {
        this.type = newType;
        this.registry = newRegistry;
        this.place = newPlace;
        this.id = currentLocalID;
        this.owners = new HashMap<Integer, User>();
        currentLocalID++;
    }

    public int getID() {
        return this.id;
    }
    public int getServerID() {
        return this.serverID;
    }
    public int getServerInfo() {
        JsonReceiverRepository connection = new JsonReceiverRepository();
        try {
            JSONArray serverVeiculo = connection.execute("/api/veiculos/"+this.serverID).get();
            JSONObject serverVeiculoObject = serverVeiculo.getJSONObject(0);
            this.setPlace(serverVeiculoObject.getString("localizacao"));
            this.setType(serverVeiculoObject.getString("tipo"));
            this.setRegistry(serverVeiculoObject.getString("matricula"));
        } catch (ExecutionException e) {
            e.printStackTrace();
        } catch (InterruptedException e) {
            e.printStackTrace();
        } catch (JSONException e) {
            e.printStackTrace();
        }
        return this.serverID;
    }
    public String getType() {
        return this.type;
    }
    public String getPlace() {
        return this.place;
    }
    public String getRegistry() {
        return this.registry;
    }
    public HashMap<Integer, User> getOwners() { return this.owners; }

    public void setPlace(String newPlace) {
        this.place = newPlace;
    }
    public void setType(String newType) {
        this.type = newType;
    }
    public void setRegistry(String newRegistry) {
        this.registry = newRegistry;
    }
    public void addOwner(User newOwner) { this.getOwners().put(newOwner.getID(), newOwner); }
    public void removeOwner(User pendingOwner) {
        this.owners.remove(pendingOwner.getID());
    }
}
