package com.example.uashapp.java.enums;

public enum TipoLavagemEnum {
    GARAGEMPRIVADA(45, "Garagem Privada"),
    POSTODELAVAGEM(30, "Posto de Lavagem"),
    LAVAGEMASECO(75, "Lavagem a Seco");
    private int price;
    private String name;
    public int getPrice() { return this.price; }
    public String getName() { return this.name; }
    public TipoLavagemEnum getType(String name) {
        if (name.equals(GARAGEMPRIVADA.getName())) {
            return GARAGEMPRIVADA;
        } else if (name.equals(POSTODELAVAGEM.getName())) {
            return POSTODELAVAGEM;
        } else if  (name.equals(LAVAGEMASECO.getName())) {
            return LAVAGEMASECO;
        }
        return null;
    }
    private TipoLavagemEnum(int newPrice, String newName) {
        this.price = newPrice;
        this.name = newName;
    }
}
