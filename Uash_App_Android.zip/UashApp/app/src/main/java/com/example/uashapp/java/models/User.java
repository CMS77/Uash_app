package com.example.uashapp.java.models;

import android.os.Build;
import android.util.Log;

import com.example.uashapp.java.enums.RatingEnum;
import com.example.uashapp.java.enums.StatusEnum;
import com.example.uashapp.java.enums.TipoLavagemEnum;
import com.example.uashapp.java.repositories.JsonReceiverRepository;
import com.example.uashapp.java.repositories.JsonSenderRepository;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.Serializable;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.concurrent.ExecutionException;

    /*
    Em relação à encriptação das senhas, uma hash SHA-256 é utilizada. Ao criar uma nova senha, um usuário recebe um "sal" único (hashKey),
    que é adicionado ao fim da sua senha antes da encriptação. Essa senha então é salva no servidor, impedindo que a senha em plain text
    seja interceptada por qualquer atacante. Ao tentar fazer login, a senha digitada novamente recebe este mesmo sal e é encriptada com o mesmo
    método. Visto que o algoritmo SHA-256 é determinístico - ou seja, sempre produz os mesmos resultados com os mesmos inputs - o
    usuário receberá uma hash que será igual à sua senha se, e APENAS se, a sua senha estiver correta. Essa arquitetura "little-knowledge",
    apesar de simples, deverá ser o suficiente para impedir grande parte dos ataques.
    */

public class User implements Serializable {
    private static int currentLocalID = 1;
    private final int id;
    private int serverID;
    private Uasher uasher;
    private String name;
    private byte[] password; //hashed
    //private long hashKey; Como passar o hashKey (sal) para o servidor seria a mesma coisa que enviar a senha não encriptada, o serverID agora está sendo utilizado como sal
    private String email;
    private int phone;
    private LocalDate bdate;
    private String place;
    private RatingEnum rating;
    private HashMap<Integer, Lavagem> reqServices;
    private HashMap<Integer, Veiculo> vehicles;

    public JSONArray toJSONArray(User user) {
        JSONObject tempUser = new JSONObject();
        JSONArray result = new JSONArray();
        try {
            tempUser.put("name", this.name)
                    .put("email", this.email)
                    .put("password", this.password)
                    .put("telefone", this.phone)
                    .put("dataNasc", this.bdate)
                    .put("localizacao", this.place)
                    .put("id", this.serverID);
            result.put(tempUser);
            Log.e("User", result.toString());
            return result;
        } catch (JSONException e) {
            e.printStackTrace();
            return null;
        }
    }

    public User fromJSONArray(JSONArray array) throws JSONException {
        JSONObject userObject = array.getJSONObject(0);
        this.serverID = userObject.getInt("id");
        this.name = userObject.getString("name");
        this.email = userObject.getString("uasher");
        //this.password = userObject.getString("password").toCharArray();
        this.phone = userObject.getInt("telefone");
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            this.bdate = LocalDate.parse(userObject.getString("dataNasc"));
        }
        this.place = userObject.getString("localizacao");
        return this;
    }

    private void sendUpdateUser(String method) { // Chamar após atualizar os dados!
        JsonSenderRepository connection = new JsonSenderRepository();
        try {
            JSONArray serverUser = connection.execute("/api/users/"+this.serverID, method, toJSONArray(this).toString()).get();
        } catch (ExecutionException e) {
            e.printStackTrace();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    public User(JSONArray array) throws JSONException {
        this.id = currentLocalID;
        fromJSONArray(array);
        currentLocalID++;
    }

    public User(String newName, String newEmail, int newPhone, String newPlace) {
        this.name = newName;
        this.email = newEmail;
        this.phone = newPhone;
        this.place = newPlace;
        this.id = currentLocalID;
        this.reqServices = new HashMap<Integer, Lavagem>();
        this.vehicles = new HashMap<Integer, Veiculo>();
        JsonSenderRepository connection = new JsonSenderRepository();
        try {
            JSONArray serverUser = new JSONArray();
            serverUser = connection.execute("/api/users/", "POST", toJSONArray(this).toString()).get();
           if(!serverUser.isNull(0)) {
                JSONObject serverUserObject = serverUser.getJSONObject(1); // Objeto do user deverá ser index 1, já que message é 0
                this.serverID = serverUserObject.getInt("id");
            }
        } catch (ExecutionException e) {
            e.printStackTrace();
        } catch (InterruptedException e) {
            e.printStackTrace();
        } catch (JSONException e) {
            e.printStackTrace();
        } catch (NullPointerException e) {
            e.printStackTrace();
        }
        currentLocalID++;
    }

    public int getID() {
        return this.id;
    }
    public int getServerID() {
        return this.serverID;
    }
    public int getServerInfo() {
        JsonReceiverRepository connection = new JsonReceiverRepository();
        try {
            JSONArray serverUser = connection.execute("/api/users/"+this.serverID).get();
            JSONObject serverUserObject = serverUser.getJSONObject(0);
            this.setName(serverUserObject.getString("name"));
            this.setEmail(serverUserObject.getString("email"));
            this.setPhone(serverUserObject.getInt("telefone"));
            this.setBirthday(serverUserObject.getString("dataNasc"));
            this.setPlace(serverUserObject.getString("localizacao"));
        } catch (ExecutionException e) {
            e.printStackTrace();
        } catch (InterruptedException e) {
            e.printStackTrace();
        } catch (JSONException e) {
            e.printStackTrace();
        }
        return this.serverID;
    }
    public Uasher getUasher() {
        return this.uasher;
    }
    public String getName() {
        return this.name;
    }
    public String getEmail() {
        return this.email;
    }
    public int getPhone() {
        return this.phone;
    }
    public LocalDate getAge() {
        return this.bdate;
    }
    public String getPlace() {
        return this.place;
    }
    public RatingEnum getRating() {
        return this.rating;
    }
    public HashMap<Integer, Lavagem> getReqServices() { return this.reqServices; }
    public HashMap<Integer, Veiculo> getVehicles() { return this.vehicles; }

    public Uasher setUasher(String newLicense) {
        Uasher tempUasher = new Uasher(this, newLicense);
        this.uasher = tempUasher;
        tempUasher = null; // Para o garbage collector
        return this.uasher;
    }
    public void setName(String newName) {
        this.name = newName;
    }
    private byte[] hashPassword(String password) {
        String saltedPassword = password + this.serverID; // this.hashKey
        MessageDigest md = null;
        try {
            md = MessageDigest.getInstance("SHA-256");
        } catch (NoSuchAlgorithmException e) {
            e.printStackTrace();
        }
        md.update((byte) this.serverID); // this.hashKey
        byte[] encryptedPassword = md.digest(saltedPassword.getBytes(StandardCharsets.UTF_8));
        return encryptedPassword;
    }
    public void setPassword(String newPassword) {
        SecureRandom random = new SecureRandom();
        //random.setSeed(System.currentTimeMillis());
        long salt = random.nextLong();
        this.password = hashPassword(newPassword);
        sendUpdateUser("PUT");
    }
    public boolean verifyPassword(String password) {
        JsonReceiverRepository connection = new JsonReceiverRepository();
        try {
            JSONArray serverUser = connection.execute("/api/users/"+this.serverID).get();
            JSONObject serverUserObject = serverUser.getJSONObject(0);
            return hashPassword(password).equals(serverUserObject.getString("password"));
        } catch (ExecutionException e) {
            e.printStackTrace();
        } catch (InterruptedException e) {
            e.printStackTrace();
        } catch (JSONException e) {
            e.printStackTrace();
        }
        return false;
    }
    public void setEmail(String newEmail) {
        this.email = newEmail;
    }
    public void setPhone(int newPhone) {
        this.phone = newPhone;
    }
    public void setBirthday(String newBdate) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) { // obrigado, android studio??
            this.bdate = LocalDate.parse(newBdate);
        }
    }
    public void setPlace(String newPlace) {
        this.place = newPlace;
    }
    public void setRating(RatingEnum newRating) {
        this.rating = newRating;
    }
    public void addReqService(Lavagem newService) { this.reqServices.put(newService.getID(), newService); }
    public void removeReqService(Lavagem pendingService) {
        this.reqServices.remove(pendingService.getID());
    }
    public void addVehicle(Veiculo newVehicle) { this.vehicles.put(newVehicle.getID(), newVehicle); }
    public void removeVehicle(Veiculo newVehicle) {
        newVehicle.removeOwner(this);
        this.vehicles.remove(newVehicle.getID());
    }
}
