package com.example.uashapp.java.enums;

public enum TipoLavagemEnum {
    GARAGEMPRIVADA, POSTODELAVAGEM, LAVAGEMASECO;
}
