package com.example.uashapp.java.enums;

public enum StatusEnum {
    SOLICITADO, CONFIRMADO, AGENDADO, CANCELADO;
}
